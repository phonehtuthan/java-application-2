/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;
import java.sql.*;

/**
 *
 * @author northerncity
 */
public class Database {
    public Connection getConnected(){
     Connection conn=null;
     try{
         
         Class.forName("org.sqlite.JDBC");
         conn=DriverManager.getConnection("jdbc:sqlite:db2.db");
         
         if(conn!=null){
             //System.out.println("Database Connection Success...");
         }
         
     }catch(Exception e){
         e.printStackTrace();
     }
     return conn;
     
    }
}
